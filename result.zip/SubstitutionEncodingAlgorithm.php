<?php

/**
 * Class SubstitutionEncodingAlgorithm
 *  http://www.writephponline.com/
 */
class SubstitutionEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * @var array
     */
    private $substitutions;

    /**
     * SubstitutionEncodingAlgorithm constructor.
     *
     * @param $substitutions
     */
    public function __construct(array $substitutions)
    {
        $this->substitutions = $substitutions;
    }

    /**
     * Encodes text by substituting character with another one provided in the pair.
     * For example pair "ab" defines all "a" chars will be replaced with "b" and all "b" chars will be replaced with "a"
     * Examples:
     *      substitutions = ["ab"], input = "aabbcc", output = "bbaacc"
     *      substitutions = ["ab", "cd"], input = "adam", output = "bcbm"
     *
     * @param string $text
     *
     * @return string
     */
    public function encode($text)
    {
        $newString = '';

        for ($i = 0; $i < strlen($text); $i++) {
            $currentLetter  = $text[$i];
            $characterToAdd = $currentLetter;

            foreach ($this->substitutions as $substitution) {
                $indexSubstition = strpos(strtolower($substitution), strtolower($currentLetter));

                if (false !== $indexSubstition) {
                    $characterToAdd = $substitution[!$indexSubstition];
                    $characterToAdd = ctype_upper($currentLetter) ? strtoupper($characterToAdd) : $characterToAdd;
                }
            }

            $newString .= $characterToAdd;
        }

        return $newString;
    }
}
