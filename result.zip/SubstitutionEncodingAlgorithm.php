<?php

/**
 * Class SubstitutionEncodingAlgorithm
 *  http://www.writephponline.com/
 */
class SubstitutionEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * @var array
     */
    private $substitutions;

    /**
     * SubstitutionEncodingAlgorithm constructor.
     * @param $substitutions
     */
    public function __construct(array $substitutions)
    {
        $this->substitutions = $substitutions;
    }

    /**
     * Encodes text by substituting character with another one provided in the pair.
     * For example pair "ab" defines all "a" chars will be replaced with "b" and all "b" chars will be replaced with "a"
     * Examples:
     *      substitutions = ["ab"], input = "aabbcc", output = "bbaacc"
     *      substitutions = ["ab", "cd"], input = "adam", output = "bcbm"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        foreach($this->substitutions as $substitution){
            $firstChar = $substitution[0];
            $secondChar = $substitution[1];
            for($i=0;$i<strlen($text);$i++){
                $text[$i] = $this->change($text[$i], $firstChar, $secondChar);
            }
        }
        return $text;
    }

    public function change($letter, $firstChar, $secondChar){
        $typeLetter = ctype_upper($letter);
        if($typeLetter) {
            $letter = strtoupper($letter);
            $firstChar = strtoupper($firstChar);
            $secondChar = strtoupper($secondChar);
        }

        switch ($letter) {
            case $firstChar:
                $letter = $secondChar;
                return $letter;
            break;

            case $secondChar:
                $letter = $firstChar;
                return $letter;
            break;
            
            default:
                return $letter;
            break;
        }
    }
    
}