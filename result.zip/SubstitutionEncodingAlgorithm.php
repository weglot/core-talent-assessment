<?php

/**
 * Class SubstitutionEncodingAlgorithm
 *  http://www.writephponline.com/
 */
class SubstitutionEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * @var array
     */
    private $substitutions;

    /**
     * SubstitutionEncodingAlgorithm constructor.
     * @param $substitutions
     */
    public function __construct(array $substitutions)
    {
        $this->substitutions = $substitutions;
    }

    /**
     * Encodes text by substituting character with another one provided in the pair.
     * For example pair "ab" defines all "a" chars will be replaced with "b" and all "b" chars will be replaced with "a"
     * Examples:
     *      substitutions = ["ab"], input = "aabbcc", output = "bbaacc"
     *      substitutions = ["ab", "cd"], input = "adam", output = "bcbm"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        if (isset($text) && is_string($text))
        {
            $ret = $text;
            foreach ($this->substitutions as $pair)
            {
                $dpair = strtolower($pair);
                $upair = strtoupper($pair);
                $ret = strtr($ret,[$dpair[0]=>$dpair[1], $dpair[1]=>$dpair[0]]);
                $ret = strtr($ret,[$upair[0]=>$upair[1], $upair[1]=>$upair[0]]);

            }

            return $ret;
        }

        return '';
    }
}