<?php

/**
 * Class SubstitutionEncodingAlgorithm
 *  http://www.writephponline.com/
 */
class SubstitutionEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * @var array
     */
    private $substitutions;

    /**
     * SubstitutionEncodingAlgorithm constructor.
     * @param $substitutions
     */
    public function __construct(array $substitutions)
    {
        $this->substitutions = $substitutions;
    }

    /**
     * Encodes text by substituting character with another one provided in the pair.
     * For example pair "ab" defines all "a" chars will be replaced with "b" and all "b" chars will be replaced with "a"
     * Examples:
     *      substitutions = ["ab"], input = "aabbcc", output = "bbaacc"
     *      substitutions = ["ab", "cd"], input = "adam", output = "bcbm"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        $output = "";
        $found = array();
        foreach($this->substitutions as $sub) {
            for ($i = 0; $i < strlen($text); $i++) {
                if (stripos($sub, $text[$i]) === 0) {
                    $output[$i] = $sub[1];
                    array_push($found, $i);
                } else if (stripos($sub, $text[$i]) === 1) {
                    $output[$i] = $sub[0];
                    array_push($found, $i);                    
                } else if (in_array($i, $found) === false){
                    $output[$i] = $text[$i];
                }
                if (ctype_upper($text[$i])) {
                    $output[$i] = strtoupper($output[$i]);
                }
            }
        }
        return $output;
    }
    }