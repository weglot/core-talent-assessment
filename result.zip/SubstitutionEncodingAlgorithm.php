<?php

/**
 * Class SubstitutionEncodingAlgorithm
 *  http://www.writephponline.com/
 */
class SubstitutionEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * @var array
     */
    private $substitutions;

    /**
     * SubstitutionEncodingAlgorithm constructor.
     * @param $substitutions
     */
    public function __construct(array $substitutions)
    {
        $this->substitutions = $substitutions;
    }

    /**
     * Encodes text by substituting character with another one provided in the pair.
     * For example pair "ab" defines all "a" chars will be replaced with "b" and all "b" chars will be replaced with "a"
     * Examples:
     *      substitutions = ["ab"], input = "aabbcc", output = "bbaacc"
     *      substitutions = ["ab", "cd"], input = "adam", output = "bcbm"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        /**
         * @TODO: Implement it
         */
        $arr1 = array();
        $arr2 = array();

        $substituteText = '';
        $arrayInput = str_split($text);
        foreach($this->substitutions as $sub)
        {
            $arr1[] = substr($sub,0,1);
            $arr2[] = substr($sub,1,1);
        }

        foreach($arrayInput as $letter) 
        {
            if(in_array($letter, $arr1)) {
               $posInArray = array_search($letter, $arr1);
               $replace = $arr2[$posInArray];
               $substituteText .= str_replace($letter,$replace,$letter);
            } elseif(in_array($letter, $arr2)) {
               $posInArray = array_search($letter, $arr2);
               $replace = $arr1[$posInArray];
               $substituteText .= str_replace($letter,$replace,$letter);
            } elseif(in_array(strtolower($letter), $arr1)) {
                $posInArray = array_search(strtolower($letter), $arr1);
                $replace = $arr2[$posInArray];
                $substituteText .= strtoupper(str_replace($letter,$replace,$letter));
            } elseif(in_array(strtolower($letter), $arr2)) {
                $posInArray = array_search(strtolower($letter), $arr2);
                $replace = $arr1[$posInArray];
                $substituteText .= strtoupper(str_replace($letter,$replace,$letter));
            }
            else {
                $substituteText .= $letter;
            }
        }
        return $substituteText;
    }
}