<?php

/**
 * Class SubstitutionEncodingAlgorithm
 *  http://www.writephponline.com/
 */
class SubstitutionEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * @var array
     */
    private $substitutions;

    /**
     * SubstitutionEncodingAlgorithm constructor.
     * @param $substitutions
     */
    public function __construct(array $substitutions)
    {
        $this->substitutions = $substitutions;
    }

    /**
     * Encodes text by substituting character with another one provided in the pair.
     * For example pair "ab" defines all "a" chars will be replaced with "b" and all "b" chars will be replaced with "a"
     * Examples:
     *      substitutions = ["ab"], input = "aabbcc", output = "bbaacc"
     *      substitutions = ["ab", "cd"], input = "adam", output = "bcbm"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        foreach (str_split($text) as $idx => $letter) {
            if (empty($letter)) continue;
            foreach ($this->substitutions as $substitution) {
                // substitution test is case sensitive, input should match substitution for that
                $subCaseNonSensitive = ctype_upper($letter) ? strtoupper($substitution) : strtolower($substitution);
                $idxSub = strpos($subCaseNonSensitive, $letter);
                if ($idxSub !== false) { // if letter matches a substitution
                    $text[$idx] = $subCaseNonSensitive[($idxSub ^ 1)]; // if not index 0 then 1 (and vice versa)
                    break;
                }
            }
        }
        return $text;
    }
}
