<?php

/**
 * Class SubstitutionEncodingAlgorithm
 *  http://www.writephponline.com/
 */


class SubstitutionEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * @var array
     */
    private $substitutions;

    /**
     * SubstitutionEncodingAlgorithm constructor.
     * @param $substitutions
     */
    public function __construct(array $substitutions)
    {
        $this->substitutions = $substitutions;
    }

    /**
     * Encodes text by substituting character with another one provided in the pair.
     * For example pair "ab" defines all "a" chars will be replaced with "b" and all "b" chars will be replaced with "a"
     * Examples:
     *      substitutions = ["ab"], input = "aabbcc", output = "bbaacc"
     *      substitutions = ["ab", "cd"], input = "adam", output = "bcbm"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        /**
         * @TODO: Implement it
         */
        $countPair=0;
        $isUpper=false;

        //Si le texte est en majuscule :
        if ($text == strtoupper($text)) $isUpper=true;

        // On parcours les paires
        while($countPair<count($this->substitutions)){
            //On transforme la paire actuelle en majuscule si isUpper = true
            if($isUpper) $this->substitutions[$countPair] = strtoupper($this->substitutions[$countPair]);
            //On parcours le string
            for($i=0; $i<strlen($text);$i++){
                // Si la lettre est egale à la premiere lettre de la paire
                if(substr($text,$i,1)==substr($this->substitutions[$countPair],0,1 )){
                    //on la remplace par la deuxieme
                    $text=substr_replace($text, substr($this->substitutions[$countPair],1,1 ),$i,1);
                 // Et inversement
                }elseif (substr($text,$i,1)==substr($this->substitutions[$countPair],1,1 )){
                    $text=substr_replace($text, substr($this->substitutions[$countPair],0,1 ),$i,1);
                }
            }
            $countPair++;
        }
        return $text;
    }
}