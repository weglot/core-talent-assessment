<?php

/**
 * Class SubstitutionEncodingAlgorithm
 *  http://www.writephponline.com/
 */
class SubstitutionEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * @var array
     */
    private $substitutions;

    /**
     * SubstitutionEncodingAlgorithm constructor.
     * @param $substitutions
     */
    public function __construct(array $substitutions)
    {
        $this->substitutions = $substitutions;
    }

    /**
     * Encodes text by substituting character with another one provided in the pair.
     * For example pair "ab" defines all "a" chars will be replaced with "b" and all "b" chars will be replaced with "a"
     * Examples:
     *      substitutions = ["ab"], input = "aabbcc", output = "bbaacc"
     *      substitutions = ["ab", "cd"], input = "adam", output = "bcbm"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        /** string $code */
        $code = $text;

        for($i = 0; $i<strlen($text); $i++) {
            for($j = 0; $j<count($this->substitutions); $j++) {
                // case-insensitive comparison
                if( strcasecmp($code[$i], $this->substitutions[$j][0]) == 0 ) {
                    $code[$i] = $this->substitutions[$j][1];
                }
                elseif( strcasecmp($code[$i], $this->substitutions[$j][1]) == 0 ) {
                    $code[$i] = $this->substitutions[$j][0];
                }
                else {
                    continue;
                }

                // maintain original character case
                $code[$i] = ctype_upper($text[$i]) ? strtoupper($code[$i]) : strtolower($code[$i]);
            }
        }

        return $code;
    }
}