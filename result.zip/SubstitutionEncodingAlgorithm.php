<?php

/**
 * Class SubstitutionEncodingAlgorithm
 *  http://www.writephponline.com/
 */
class SubstitutionEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * @var array
     */
    private $substitutions;

    /**
     * SubstitutionEncodingAlgorithm constructor.
     * @param $substitutions
     */
    public function __construct(array $substitutions)
    {
        $substitutionPairs = [];
        foreach ($substitutions as $substitution) {
            [$from, $to] = str_split($substitution);
            $substitutionPairs[strtolower($from)] = strtolower($to);
            $substitutionPairs[strtoupper($from)] = strtoupper($to);
            $substitutionPairs[strtolower($to)] = strtolower($from);
            $substitutionPairs[strtoupper($to)] = strtoupper($from);
        }

        $this->substitutions = $substitutionPairs;
    }

    /**
     * Encodes text by substituting character with another one provided in the pair.
     * For example pair "ab" defines all "a" chars will be replaced with "b" and all "b" chars will be replaced with "a"
     * Examples:
     *      substitutions = ["ab"], input = "aabbcc", output = "bbaacc"
     *      substitutions = ["ab", "cd"], input = "adam", output = "bcbm"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        // Here we use strtr instead of str_replace to avoid replacing several times a char
        return strtr($text, $this->substitutions);
    }
}
