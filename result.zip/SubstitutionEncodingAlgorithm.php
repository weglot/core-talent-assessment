<?php

/**
 * Class SubstitutionEncodingAlgorithm
 *  http://www.writephponline.com/
 */
class SubstitutionEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * @var array
     */
    private $substitutions;

    /**
     * SubstitutionEncodingAlgorithm constructor.
     * @param $substitutions
     */
    public function __construct(array $substitutions)
    {
        $this->substitutions = $substitutions;
    }

    /**
     * Encodes text by substituting character with another one provided in the pair.
     * For example pair "ab" defines all "a" chars will be replaced with "b" and all "b" chars will be replaced with "a"
     * Examples:
     *      substitutions = ["ab"], input = "aabbcc", output = "bbaacc"
     *      substitutions = ["ab", "cd"], input = "adam", output = "bcbm"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        /**
         * @TODO: Implement it
         */
        foreach ($this->substitutions as $substitutionChars) {
            $splitSubstitutionChars = str_split($substitutionChars);
            $first = $splitSubstitutionChars[0];
            $second = $splitSubstitutionChars[1];
            $text = preg_replace_callback("/$first|$second/i", function ($matches) use ($first, $second) {
                $iFirst = array($first, strtoupper($first));
                $iSecond = array($second, strtoupper($second));
                return strtolower($matches[0]) === $first
                    ? str_replace($iFirst, $iSecond, $matches[0])
                    : str_replace($iSecond, $iFirst, $matches[0]);
            }, $text);
        }

        return $text;
    }
}