<?php

/**
 * Class SubstitutionEncodingAlgorithm
 *  http://www.writephponline.com/
 */
class SubstitutionEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * @var array
     */
    private $substitutions;

    /**
     * SubstitutionEncodingAlgorithm constructor.
     * @param $substitutions
     */
    public function __construct(array $substitutions)
    {
        $this->substitutions = $substitutions;
    }

    /**
     * Encodes text by substituting character with another one provided in the pair.
     * For example pair "ab" defines all "a" chars will be replaced with "b" and all "b" chars will be replaced with "a"
     * Examples:
     *      substitutions = ["ab"], input = "aabbcc", output = "bbaacc"
     *      substitutions = ["ab", "cd"], input = "adam", output = "bcbm"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        /**
         * @TODO: Implement it
         */

        $result = '';
        
        $swaps = [];
        
        foreach($this->substitutions as $sub) {
            $stock = str_split($sub);
            $swaps[] = mb_strtolower($stock[0]);
            $swaps[] = mb_strtolower($stock[1]);
            $swaps[] = mb_strtoupper($stock[0]);
            $swaps[] = mb_strtoupper($stock[1]);
        }

        foreach(str_split($text) as $letter){
            if(in_array($letter, $swaps)) {
                $pos = array_search($letter, $swaps);
                
                if($pos % 2 === 0) {
                    $result .= $swaps[$pos + 1];
                }
                else {
                    $result .= $swaps[$pos - 1];
                }
            }
            else{
                $result .= $letter;
            }
        }
    
        return $result;
    }
}