<?php

/**
 * Class SubstitutionEncodingAlgorithm
 *  http://www.writephponline.com/
 */
class SubstitutionEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * @var array
     */
    private $substitutions;

    /**
     * SubstitutionEncodingAlgorithm constructor.
     * @param $substitutions
     */
    public function __construct(array $substitutions)
    {
        $this->substitutions = $substitutions;
    }

    /**
     * Encodes text by substituting character with another one provided in the pair.
     * For example pair "ab" defines all "a" chars will be replaced with "b" and all "b" chars will be replaced with "a"
     * Examples:
     *      substitutions = ["ab"], input = "aabbcc", output = "bbaacc"
     *      substitutions = ["ab", "cd"], input = "adam", output = "bcbm"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        $encoded_text = $text;

        foreach ($this->substitutions as $pair){

            for ($i = 0; $i < strlen($text); $i++){
                if (strcasecmp($text[$i], $pair[0]) == 0){
                    $encoded_text[$i] = $pair[1];
                }
                elseif (strcasecmp($text[$i], $pair[1]) == 0) {
                    $encoded_text[$i] = $pair[0];
                }

                if (ctype_upper($text[$i])){
                    $encoded_text[$i] = strtoupper($encoded_text[$i]);
                }
                
            }
        }

        return $encoded_text;
    }
}