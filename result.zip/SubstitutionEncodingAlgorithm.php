<?php

/**
 * Class SubstitutionEncodingAlgorithm
 *  http://www.writephponline.com/
 */
class SubstitutionEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * @var array
     */
    private $substitutions;

    /**
     * SubstitutionEncodingAlgorithm constructor.
     * @param $substitutions
     */
    public function __construct(array $substitutions)
    {
        $this->substitutions = $substitutions;
    }

    /**
     * Encodes text by substituting character with another one provided in the pair.
     * For example pair "ab" defines all "a" chars will be replaced with "b" and all "b" chars will be replaced with "a"
     * Examples:
     *      substitutions = ["ab"], input = "aabbcc", output = "bbaacc"
     *      substitutions = ["ab", "cd"], input = "adam", output = "bcbm"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        /**
         * @TODO: Implement it
         */

        $output = [];
        $match = [];

        foreach($this->substitutions as $substitution){
            [$l1, $l2] = str_split($substitution);
            $match[$l1] = $l2;
            $match[$l2] = $l1;
            $match[strtoupper($l1)] = strtoupper($l2);
            $match[strtoupper($l2)] = strtoupper($l1);
        }

        $textLetters = str_split($text);
        foreach($textLetters as $letter) {
            if (isset($match[$letter])) {
                $output[] = $match[$letter];
                continue;
            }
            $output[] = $letter;
        }

        return implode("", $output);
    }
}
