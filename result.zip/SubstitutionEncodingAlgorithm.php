<?php

/**
 * Class SubstitutionEncodingAlgorithm
 *  http://www.writephponline.com/
 */
class SubstitutionEncodingAlgorithm implements EncodingAlgorithm
{
    const   TARGET      = 0;
    const   SUBSTITUTE  = 1;

    /**
     * @var array
     */
    private $substitutions;

    /**
     * SubstitutionEncodingAlgorithm constructor.
     * @param $substitutions
     */
    public function __construct(array $substitutions)
    {
        $this->substitutions = $substitutions;
    }

    /**
     * Encodes text by substituting character with another one provided in the pair.
     * For example pair "ab" defines all "a" chars will be replaced with "b" and all "b" chars will be replaced with "a"
     * Examples:
     *      substitutions = ["ab"], input = "aabbcc", output = "bbaacc"
     *      substitutions = ["ab", "cd"], input = "adam", output = "bcbm"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        if ($text && isset($this->substitutions)) {
            $encoded    = array();
            $decoded    = str_split($text, 1);

            foreach ($decoded as $key => $element) {
                $encoded[$key]     = $element;
                $elemLowered       = strtolower($element);

                foreach ($this->substitutions as $encoding) {
                    if ($elemLowered == $encoding[self::TARGET]) {
                        $encoded[$key]  = $encoding[self::SUBSTITUTE];
                    }

                    if ($elemLowered == $encoding[self::SUBSTITUTE]) {
                        $encoded[$key]  = $encoding[self::TARGET];
                    }

                    if (ctype_upper($element)) {
                        $encoded[$key]  = strtoupper($encoded[$key]);
                    }
                }
            }

            $result = implode("", $encoded);

            return $result;
        }

        return '';
    }
}