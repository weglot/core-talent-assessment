<?php

/**
 * Class SubstitutionEncodingAlgorithm
 *  http://www.writephponline.com/
 */
class SubstitutionEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * @var array
     */
    private $substitutions;

    /**
     * SubstitutionEncodingAlgorithm constructor.
     * @param $substitutions
     */
    public function __construct(array $substitutions)
    {
        $this->substitutions = $substitutions;
    }

    /**
     * Encodes text by substituting character with another one provided in the pair.
     * For example pair "ab" defines all "a" chars will be replaced with "b" and all "b" chars will be replaced with "a"
     * Examples:
     *      substitutions = ["ab"], input = "aabbcc", output = "bbaacc"
     *      substitutions = ["ab", "cd"], input = "adam", output = "bcbm"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        /**
         * @TODO: Implement it
         */

        $result = '';

        $allSubs = '';

        foreach ($this->substitutions as $substitution) {
            $origin = str_split($substitution);
            $allSubs .= strtolower($origin[0]);
            $allSubs .= strtolower($origin[1]);
            $allSubs .= strtoupper($origin[0]);
            $allSubs .= strtoupper($origin[1]);
        }

        foreach (str_split($text) as $letter) {
            if($letter !== '') $letterPos = strpos($allSubs, $letter);
            else $letterPos = false;

            if ($letterPos === false) $result .= $letter;
            else {
                if ($letterPos % 2 === 0) $result .= $allSubs[$letterPos + 1];
                else $result .= $allSubs[$letterPos - 1];
            }
        }

        return $result;
    }
}
