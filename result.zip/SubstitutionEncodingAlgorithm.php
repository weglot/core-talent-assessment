<?php

/**
 * Class SubstitutionEncodingAlgorithm
 *  http://www.writephponline.com/
 */
class SubstitutionEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * @var array
     */
    private $substitutions;

    /**
     * SubstitutionEncodingAlgorithm constructor.
     * @param $substitutions
     */
    public function __construct(array $substitutions)
    {
        $this->substitutions = $substitutions;
    }

    /**
     * Encodes text by substituting character with another one provided in the pair.
     * For example pair "ab" defines all "a" chars will be replaced with "b" and all "b" chars will be replaced with "a"
     * Examples:
     *      substitutions = ["ab"], input = "aabbcc", output = "bbaacc"
     *      substitutions = ["ab", "cd"], input = "adam", output = "bcbm"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        // Is there any uppercase character
        ctype_upper(substr($text, 0, 1)) ? $isUppercase = true : $isUppercase = false;

        // for each combination, edit $text
        foreach($this->substitutions as $substitution) {
            $letter1 = $isUppercase ? strtoupper(substr($substitution, 0, 1)) : substr($substitution, 0, 1);
            $letter2 = $isUppercase ?  strtoupper(substr($substitution, 1, 1)) : substr($substitution, 1, 1);

            $text = str_replace($letter1, 0, $text);
            $text = str_replace($letter2, $letter1, $text);
            $text = str_replace(0, $letter2, $text);
        }

        return $text;
    }
}