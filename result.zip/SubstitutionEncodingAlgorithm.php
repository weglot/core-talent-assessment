<?php

/**
 * Class SubstitutionEncodingAlgorithm
 *  http://www.writephponline.com/
 */
class SubstitutionEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * @var array
     */
    private $substitutions;

    /**
     * SubstitutionEncodingAlgorithm constructor.
     * @param $substitutions
     */
    public function __construct(array $substitutions)
    {
        $this->substitutions = $substitutions;
    }

    /**
     * Encodes text by substituting character with another one provided in the pair.
     * For example pair "ab" defines all "a" chars will be replaced with "b" and all "b" chars will be replaced with "a"
     * Examples:
     *      substitutions = ["ab"], input = "aabbcc", output = "bbaacc"
     *      substitutions = ["ab", "cd"], input = "adam", output = "bcbm"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        /**
         * @TODO: Implement it
         */

        $is_upper = strtoupper($text) == $text ? true : false;

        foreach ( $this->substitutions as $delimiter){
            $to_find = $delimiter[0];
            $to_replace = $delimiter[1];

            $substitute = '*';

            $text = str_ireplace($to_find, $substitute, $text );

            $text = str_ireplace($to_replace, $to_find, $text );

            $text = str_ireplace($substitute, $to_replace, $text );

            if( $is_upper ){
                $text = strtoupper( $text );
            }
        }

        return $text;
    }
}