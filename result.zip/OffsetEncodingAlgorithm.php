<?php

include 'CircularLinkedList.php';

/**
 * Class OffsetEncodingAlgorithm
 */
class OffsetEncodingAlgorithm
{
    /**
     * Lookup string
     */
    const CHARACTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    /**
     * @var int
     */
    private $offset;
    private $circular_linked_list;
    /**
     * @param int $offset
     */
    public function __construct($offset = 13)
    {
        $this->offset = $offset;

	   $this->circular_linked_list = new CircularLinkedList(self::CHARACTERS);
	   $this->circular_linked_list->createList();
    }

    /**
     * Encodes text by shifting each character (existing in the lookup string) by an offset (provided in the constructor)
     * Examples:
     *      offset = 1, input = "a", output = "b"
     *      offset = 2, input = "z", output = "B"
     *      offset = 1, input = "Z", output = "a"
     *
     * @param string $text
     * @return string
     */
    public function encode(string $text)
    {
        // TODO
    	if (empty($text))
    		return "";

    	$textArray = str_split($text);

    	$encodedString = '';

    	for ($i = 0; $i < count($textArray); $i++)
    	{
    		if ($textArray[$i] === " " || $textArray[$i] === ".")
            {
    			$encodedString .= $textArray[$i];
            }
            else{
                $node = $this->circular_linked_list->getNode($textArray[$i]);
                if ($offset === 0)
                 	$encodedString  .= $node->data;
                else{
                	$encodedString  .=  $this->circular_linked_list->getencodedLetter($node, $this->offset);
                }
            }
        }

    	return $encodedString;
    }
}
