<?php

/**
 * Class OffsetEncodingAlgorithm
 */
class OffsetEncodingAlgorithm
{
    /**
     * Lookup string
     */
    const CHARACTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    /**
     * @var int
     */
    private $offset;

    /**
     * @param int $offset
     */
    public function __construct($offset = 13)
    {
        $this->offset = $offset;
    }

    /**
     * Encodes text by shifting each character (existing in the lookup string) by an offset (provided in the constructor)
     * Examples:
     *      offset = 1, input = "a", output = "b"
     *      offset = 2, input = "z", output = "B"
     *      offset = 1, input = "Z", output = "a"
     *
     * @param string $text
     * @return string
     */
    public function encode(string $text)
    {
       // Format $text to array
       $splited_text = str_split($text);
       // For each character's iteration of this array apply the encoding. If empty return empty
        $encoded_map = (!empty($text)) ? array_map(function($c){
           // If the current character is not null and is part of the list of __CHARACTERS__
           if(strpos(self::CHARACTERS,$c) !== false){
               $characters = self::CHARACTERS;
               // Looking for the current character's position
               $position_c = strpos($characters,$c)+1;  
               // Calculate the new character position by increasing its value with the offset
               $new_index = $position_c + $this->offset;

               // Retrieving the max length of characters list
               $len_characters = strlen($characters);

               // If the index is greater than the total of remaining length we start again at index(0)
               if($new_index > $len_characters){
                   while ($new_index / $len_characters > 1) {
                       $new_index = $new_index - $len_characters;
                   } 
               }
           }
           return (isset($characters)) ? $characters[$new_index-1] : $c;
       },$splited_text) : '';

       // Format array to text and return
       return (is_array($encoded_map)) ? implode($encoded_map) : $encoded_map ;
    }
}
