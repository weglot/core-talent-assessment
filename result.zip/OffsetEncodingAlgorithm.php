<?php

/**
 * Class OffsetEncodingAlgorithm
 */
class OffsetEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * Lookup string
     */
    const CHARACTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    /**
     * Limit of character's array
     */
    const LIMIT = 52;

    /**
     * @var int
     */
    private $offset;

    /**
     * @param int $offset
     */
    public function __construct($offset = 13)
    {
        $this->offset = $offset;
    }

    /**
     * Encodes text by shifting each character (existing in the lookup string) by an offset (provided in the constructor)
     * Examples:
     *      offset = 1, input = "a", output = "b"
     *      offset = 2, input = "z", output = "B"
     *      offset = 1, input = "Z", output = "a"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        if ($text && $this->offset > 0) {
            $encoded    = array();
            $decoded    = str_split($text, 1);
            $characters = str_split(self::CHARACTERS, 1);

            foreach ($decoded as $key => $element) {
                $position       = array_search($element, $characters);
                $offset         = $position + $this->offset;
                $encoded[$key]  = $element;

                if ($element == $characters[$position]) {
                    $offset        = $offset >= self::LIMIT ? $offset % self::LIMIT : $offset;
                    $encoded[$key] = $characters[$offset];
                }
            }

            $result = implode("", $encoded);

            return $result;
        }

        return $text;
    }
}