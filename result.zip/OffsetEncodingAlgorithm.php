<?php

/**
 * Class OffsetEncodingAlgorithm
 */


class OffsetEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * Lookup string
     */
    const CHARACTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    /**
     * @var int
     */
    private $offset;

    /**
     * @param int $offset
     */
    public function __construct($offset = 13)
    {
        $this->offset = $offset;
    }

    /**
     * Encodes text by shifting each character (existing in the lookup string) by an offset (provided in the constructor)
     * Examples:
     *      offset = 1, input = "a", output = "b"
     *      offset = 2, input = "z", output = "B"
     *      offset = 1, input = "Z", output = "a"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        /**
         * @TODO: Implement it
         */

        // On crée une variable pour le mot retourné
        $motRetour = "";
        // On parcours le String
        for($i=0; $i<strlen($text); $i++){
            $char=substr($text,$i,1);
            // Si le caractere est une lettre
            if(ctype_alpha($char)){
                $j=0;
                // On recherche la lettre dans la liste de caractere
                while($char!=substr(self::CHARACTERS,$j,1)){
                    $j++;
                }
                // Puis on l'ajoute au mot retourné
                $motRetour=$motRetour.substr(self::CHARACTERS,($j+($this->offset))%52,1);
            }else{
                // Sinon, on ajoute le caractere tel quel au mot retourné
                $motRetour=$motRetour.$char;
            }
        }
        return $motRetour;
    }
}