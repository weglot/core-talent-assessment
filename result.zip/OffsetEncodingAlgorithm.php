<?php

/**
 * Class OffsetEncodingAlgorithm
 */
class OffsetEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * Lookup string
     */
    const CHARACTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    /**
     * @var int
     */
    private $offset;

    /**
     * @param int $offset
     */
    public function __construct($offset = 13)
    {
        $this->offset = $offset;
    }

    /**
     * Encodes text by shifting each character (existing in the lookup string) by an offset (provided in the constructor)
     * Examples:
     *      offset = 1, input = "a", output = "b"
     *      offset = 2, input = "z", output = "B"
     *      offset = 1, input = "Z", output = "a"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        /** string $code */
        $code = $text;

        for($i = 0; $i<strlen($text); $i++) {
            $indexOfChar = strpos(self::CHARACTERS, $text[$i]);
            
            if($indexOfChar !== false) // should test if current character EXISTS in the lookup string
                $code[$i] = self::CHARACTERS[($indexOfChar + $this->offset) % strlen(self::CHARACTERS)];
        }

        return $code;
    }
}