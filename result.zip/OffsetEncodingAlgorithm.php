<?php

/**
 * Class OffsetEncodingAlgorithm
 */
class OffsetEncodingAlgorithm
{
    /**
     * Lookup string
     */
    const CHARACTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    /**
     * @var int
     */
    private $offset;

    /**
     * @param int $offset
     */
    public function __construct($offset = 13)
    {
        $this->offset = $offset;

        if ($this->offset > strlen(self::CHARACTERS)) {
            $this->offset = $offset % strlen(self::CHARACTERS);
        }
    }

    /**
     * Encodes text by shifting each character (existing in the lookup string) by an offset (provided in the constructor)
     * Examples:
     *      offset = 1, input = "a", output = "b"
     *      offset = 2, input = "z", output = "B"
     *      offset = 1, input = "Z", output = "a"
     *
     * @param string $text
     * @return string
     */
    public function encode(string $text)
    {
        $lookupLength = strlen(self::CHARACTERS);
        $lookupAsArray = str_split(self::CHARACTERS);
        $result = '';

        foreach (str_split($text) as $char) {
            if (false === in_array($char, $lookupAsArray)) {
                $result .= $char;

                continue;
            }

            $pos = strpos(self::CHARACTERS, $char);

            if ($pos + 1 + $this->offset > $lookupLength) {
                $result .= $lookupAsArray[$pos + $this->offset - $lookupLength];
            } else {
                $result .= $lookupAsArray[$pos + $this->offset];
            }
        }

        return $result;
    }
}
