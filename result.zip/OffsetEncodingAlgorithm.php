<?php

/**
 * Class OffsetEncodingAlgorithm
 */
class OffsetEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * Lookup string
     */
    const CHARACTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    /**
     * @var int
     */
    private $offset;

    /**
     * @param int $offset
     */
    public function __construct($offset = 13)
    {
        $this->offset = $offset;
    }

    /**
     * Encodes text by shifting each character (existing in the lookup string) by an offset (provided in the constructor)
     * Examples:
     *      offset = 1, input = "a", output = "b"
     *      offset = 2, input = "z", output = "B"
     *      offset = 1, input = "Z", output = "a"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        /**
         * @TODO: Implement it
         */

        if($this->offset === 0 || $this->offset === strlen(self::CHARACTERS)) {
            return $text;
        }

        if($text === '') {
            return $text;
        }
        else{
            $result = '';

            foreach(str_split($text) as $letter) {

                $letter_position = strpos(self::CHARACTERS, $letter);
    
                if($letter_position === false) {
                    $result .= $letter;
                }
                else{
                    $new_position = ($letter_position + $this->offset) % strlen(self::CHARACTERS);
                    $new_letter = self::CHARACTERS[$new_position];
                    $result .= $new_letter;
                }
            }
        }
        
        return $result;
    }
}