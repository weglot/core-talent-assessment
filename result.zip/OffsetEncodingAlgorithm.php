<?php

/**
 * Class OffsetEncodingAlgorithm
 */
class OffsetEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * Lookup string
     */
    const CHARACTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    /**
     * @var int
     */
    private $offset;

    /**
     * @param int $offset
     */
    public function __construct($offset = 13)
    {
        $this->offset = $offset;
    }

    /**
     * Encodes text by shifting each character (existing in the lookup string) by an offset (provided in the constructor)
     * Examples:
     *      offset = 1, input = "a", output = "b"
     *      offset = 2, input = "z", output = "B"
     *      offset = 1, input = "Z", output = "a"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        $characters = str_split($text);

        return join(array_map(function($character) use ($characters) {
            return $this->getEncodedLetter($character);
        }, $characters));
    }

    private function getEncodedLetter(string $character): string
    {
        if (!$character) {
            return $character;
        }

        // If not in the list, we just send back the character as it is
        $position = strpos(self::CHARACTERS, $character);
        if ($position === false) {
            return $character;
        }

        return self::CHARACTERS[$this->getOffset($position)];
    }

    private function getOffset(int $position): int
    {
        $newPosition = $position + $this->offset;
        // If we reached the end of the characters list, we start over
        if ($newPosition >= strlen(self::CHARACTERS)) {
            $newPosition = $newPosition - strlen(self::CHARACTERS);
        }

        return $newPosition;
    }
}
