<?php

/**
 * Class OffsetEncodingAlgorithm
 */
class OffsetEncodingAlgorithm
{
    /**
     * Lookup string
     */
    const CHARACTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    /**
     * @var int
     */
    private $offset;

    /**
     * @param int $offset
     */
    public function __construct($offset = 13)
    {
        $this->offset = $offset;
    }

    /**
     * Encodes text by shifting each character (existing in the lookup string) by an offset (provided in the constructor)
     * Examples:
     *      offset = 1, input = "a", output = "b"
     *      offset = 2, input = "z", output = "B"
     *      offset = 1, input = "Z", output = "a"
     *
     * @param string $text
     * @return string
     */
    public function encode(string $text)
    {
        if (trim($text) !== "") {
            $strlenChars = strlen(self::CHARACTERS);
            $textArray = str_split($text);
            foreach ($textArray as $item => $char) {
                $index = strpos(self::CHARACTERS, $char);
                if ($index !== false) {
                    $newIndex = $index + $this->offset;
                    if ($newIndex >= $strlenChars) {
                        $newIndex = $newIndex - $strlenChars;
                    }
                    $newChar = substr(self::CHARACTERS, $newIndex, 1);
                    $textArray[$item] = $newChar;
                }
            }
            return implode("", $textArray);
        }
        return "";
    }
}
