<?php

/**
 * Class OffsetEncodingAlgorithm
 */
class OffsetEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * Lookup string
     */
    const CHARACTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    /**
     * @var int
     */
    private $offset;

    /**
     * @param int $offset
     */
    public function __construct($offset = 13)
    {
        $this->offset = $offset;
    }

    /**
     * Encodes text by shifting each character (existing in the lookup string) by an offset (provided in the constructor)
     * Examples:
     *      offset = 1, input = "a", output = "b"
     *      offset = 2, input = "z", output = "B"
     *      offset = 1, input = "Z", output = "a"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        $splittedText = \str_split($text);
        $authorizedCharacters = \str_split(self::CHARACTERS);
        $lookupStringLength = \strlen(self::CHARACTERS);

        foreach($splittedText as $key => $character) {
            if(\in_array($character, $authorizedCharacters)) {
                $characterPosition = \strpos(self::CHARACTERS, $character);
                
                $newCharacterPosition = $characterPosition + $this->offset;
                while($newCharacterPosition >= $lookupStringLength) {
                    $newCharacterPosition = $newCharacterPosition - $lookupStringLength;
                }

                $splittedText[$key] = \substr(self::CHARACTERS, $newCharacterPosition, 1);
            }
        }

        return \implode('', $splittedText);
    }

}