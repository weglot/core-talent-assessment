<?php

/**
 * Class OffsetEncodingAlgorithm
 */
class OffsetEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * Lookup string
     */
    const CHARACTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    /**
     * @var int
     */
    private $offset;

    /**
     * @param int $offset
     */
    public function __construct($offset = 13)
    {
        $this->offset = $offset;
    }

    /**
     * Encodes text by shifting each character (existing in the lookup string) by an offset (provided in the constructor)
     * Examples:
     *      offset = 1, input = "a", output = "b"
     *      offset = 2, input = "z", output = "B"
     *      offset = 1, input = "Z", output = "a"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        /**
         * @TODO: Implement it
         */
        $maxIndex = strlen(self::CHARACTERS);
        $charsArray = str_split(self::CHARACTERS);

        $output = [];

        foreach (str_split($text) as $char) {
            $index = array_search($char, $charsArray);
            if($index === false) {
                $output[] = $char;
                continue;
            }
            $newIndex = $index + $this->offset;
            if ($newIndex >= $maxIndex) {
                $newIndex = $newIndex - $maxIndex;
            }
            $replacedChar = $charsArray[$newIndex];
            $output[] = $replacedChar;
        }

        return implode('', $output);
    }
}
