<?php

/**
 * Class OffsetEncodingAlgorithm
 */
class OffsetEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * Lookup string
     */
    const CHARACTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    /**
     * @var int
     */
    private $offset;

    /**
     * @param int $offset
     */
    public function __construct($offset = 13)
    {
        $this->offset = $offset;
    }

    /**
     * Encodes text by shifting each character (existing in the lookup string) by an offset (provided in the constructor)
     * Examples:
     *      offset = 1, input = "a", output = "b"
     *      offset = 2, input = "z", output = "B"
     *      offset = 1, input = "Z", output = "a"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        /**
         * @TODO: Implement it
         */

        $text_final = '';

        for( $i = 0; $i < strlen($text); $i++ ){

            $pos = strpos(self::CHARACTERS, $text[$i] );


            if( $pos !== false ){

                $position = $pos + $this->offset;


                if( $position > ( strlen( self::CHARACTERS ) - 1 ) ){
                   $diff = $position - strlen(self::CHARACTERS );
                   $position = $diff;

                }

                $text_final .= self::CHARACTERS[$position];
                //$text = str_replace($text[$i], self::CHARACTERS[$position], $text);
                // problem with str_replace and offset 1, every iteration it doesn't change only 1 letter, abc return ddd
            }
            else{
                $text_final .= $text[$i];
            }


        }
        return $text_final;
    }
}