<?php

/**
 * Class OffsetEncodingAlgorithm
 */
class OffsetEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * Lookup string
     */
    const CHARACTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    /**
     * @var int
     */
    private $offset;

    /**
     * @param int $offset
     */
    public function __construct($offset = 13)
    {
        $this->offset = $offset;
    }

    /**
     * Encodes text by shifting each character (existing in the lookup string) by an offset (provided in the constructor)
     * Examples:
     *      offset = 1, input = "a", output = "b"
     *      offset = 2, input = "z", output = "B"
     *      offset = 1, input = "Z", output = "a"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        /**
         * @TODO: Implement it
         */
        $encodedText = '';
        for ($i = 0; $i < strlen($text); $i++){
            
            // var_dump($text[$i]);
            $pos = strpos(self::CHARACTERS,$text[$i]);
        
            if($pos === false){
                $encodedText .= $text[$i];
            }
            else {
                $newPos = $pos + $this->offset;
                if($newPos > strlen(self::CHARACTERS)-1) {
                    $maxPos = strlen(self::CHARACTERS)-1;
                    $finalPos = $newPos - $maxPos;
                    $encodedText .= self::CHARACTERS[$finalPos-1];

                } else {
                    $encodedText .= self::CHARACTERS[$newPos];
                }
                // var_dump($pos, $newPos);die;
                
            }
        }
        return $encodedText;
    }
}