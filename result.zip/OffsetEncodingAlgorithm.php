<?php

/**
 * Class OffsetEncodingAlgorithm
 */
class OffsetEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * Lookup string
     */
    const CHARACTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    /**
     * @var int
     */
    private $offset;

    /**
     * @param int $offset
     */
    public function __construct($offset = 13)
    {
        $this->offset = $offset;
    }

    /**
     * Encodes text by shifting each character (existing in the lookup string) by an offset (provided in the constructor)
     * Examples:
     *      offset = 1, input = "a", output = "b"
     *      offset = 2, input = "z", output = "B"
     *      offset = 1, input = "Z", output = "a"
     *
     * @param string $text
     * @return string
     */
    public function encode($text): string
    {
        /* if $offset === 0 or $offset mod 52 === 0 no encoding */
        if (0 === $this->offset ||
            0 === $this->offset % strlen(self::CHARACTERS)) {
            return $text;
        }

        $result = '';

        /* apply convertLetter() on each $letter in $text to make result */
        foreach (str_split($text) as $letter) {
            $result .= $this->convertLetter($letter);
        }

        /* return string $result */
        return $result;
    }

    /**
     * Convert $letter applying offset
     *
     * @param string $letter
     * @return string
     */
    private function convertLetter($letter): string
    {
        /* if $letter is empty return $letter */
        if (empty($letter)) {
            return $letter;
        }

        /* letter position in CHARACTERS string */
        $position = strpos(self::CHARACTERS, $letter);

        /* position is false when $letter not found in self:CHARACTERS */
        if (false === $position) {
            return $letter;
        }

        /* $newPos = le reste de ($position + offset) / 52 */
        $newPos = ($position + $this->offset) % strlen(self::CHARACTERS);

        /* return new character in CHARACTERS */
        return self::CHARACTERS[$newPos];
    }
}