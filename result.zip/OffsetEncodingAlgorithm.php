<?php

/**
 * Class OffsetEncodingAlgorithm
 */
class OffsetEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * Lookup string
     */
    const CHARACTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    /**
     * @var int
     */
    private $offset;

    /**
     * @param int $offset
     */
    public function __construct($offset = 13)
    {
        $this->offset = $offset;
    }

    /**
     * Encodes text by shifting each character (existing in the lookup string) by an offset (provided in the constructor)
     * Examples:
     *      offset = 1, input = "a", output = "b"
     *      offset = 2, input = "z", output = "B"
     *      offset = 1, input = "Z", output = "a"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        $lengthCharacters = strlen(self::CHARACTERS) - 1;
        if ($text === '' && ($this->offset === 0 || 1)) {
            return '';
        }

        if (strpos($text, ' ')) {
           if ($this->offset === 0) {
               return $text;
           }

           if ($this->offset === 1) {
               return $this->strFromManual($text);
           }

           if ($this->offset === 26) {
               if (ctype_lower(str_split($text,3)[0])) {
                   return strtoupper($text);
               }

               return strtolower($text);
           }
        }

        $position = strpos(self::CHARACTERS, $text);

        if ($position < 26 && ($position + $this->offset) < 26) {
            return $this->strFromManual($text);
        }

        if ($position >= $lengthCharacters) {
            $position = $lengthCharacters - $position -1;
        }

        $output = substr(self::CHARACTERS, $position + $this->offset, 1);

        return $output;
    }

    /**
     * @param string $s
     * @return string
     */
    private function strFromManual(string $s)
    {
        $letters = self::CHARACTERS;
        $n = $this->offset;
        $n = (int)$n % 26;
        if (!$n) return $s;
        if ($n == 13) return str_rot13($s);
        for ($i = 0, $l = strlen($s); $i < $l; $i++) {
            $c = $s[$i];
            if ($c >= 'a' && $c <= 'z') {
                $s[$i] = $letters[(ord($c) - 71 + $n) % 26];
            } else if ($c >= 'A' && $c <= 'Z') {
                $s[$i] = $letters[(ord($c) - 39 + $n) % 26 + 26];
            }
        }

        return $s;
    }
}