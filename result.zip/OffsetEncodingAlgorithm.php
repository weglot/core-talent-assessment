<?php

/**
 * Class OffsetEncodingAlgorithm
 */
class OffsetEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * Lookup string
     */
    const CHARACTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    /**
     * @var int
     */
    private $offset;

    /**
     * @param int $offset
     */
    public function __construct($offset = 13)
    {
        $this->offset = $offset;
    }

    /**
     * Encodes text by shifting each character (existing in the lookup string) by an offset (provided in the constructor)
     * Examples:
     *      offset = 1, input = "a", output = "b"
     *      offset = 2, input = "z", output = "B"
     *      offset = 1, input = "Z", output = "a"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        if ($text) {
            /** @var $referenceArray */
            // Associate each character of CHARACTERS to a key in $referenceArray array
            $referenceArray = str_split(self::CHARACTERS, 1);

            /** @var $textArray */
            // Create an array with $text characters
            $textArray = str_split($text, 1);

            /**
             * @var $textKey
             * @var $character
             */
            // For each character of $textArray, find $referenceArray key and change the character using $offset
            foreach ($textArray as $textKey => $character) {
                $referenceKey = array_search($character, $referenceArray);
                // $referenceKey value verification
                if (isset($referenceKey) and $referenceKey !== false) {

                    // prevent to find a key out of $referenceArray
                    if ($referenceKey+$this->offset < sizeof($referenceArray)) {
                        $textArray[$textKey] = $referenceArray[$referenceKey+$this->offset];
                    } else {
                        $textArray[$textKey] = $referenceArray[fmod(($referenceKey+$this->offset), sizeof($referenceArray))];
                    }

                }
            }

            // return $text encrypted
            return implode($textArray);
        } else {
            return $text;
        }
    }
}