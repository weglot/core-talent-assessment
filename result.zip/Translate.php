<?php

use Google\Cloud\Translate\V2\TranslateClient;

/**
 * Class OffsetEncodingAlgorithm
 */
class Translate
{
    private $client;

    /**
     * Translate constructor.
     */
    public function __construct()
    {
        $this->client = new TranslateClient([
            'key' => 'AIzaSyDpjkvttfk-lZtZgoq_7KhrC6VIQAbiVdQ'
        ]);
    }

    /**
     * Return bool to know if language pair is supported.
     * @param string $sourceLanguage
     * @param string $targetLanguage
     * @return bool
     */
    public function isSupported(string $sourceLanguage, string $targetLanguage)
    {
        $languages = $this->client->languages();
        
        $source =  in_array($sourceLanguage,$languages);
        $target =  in_array($targetLanguage,$languages);

        return ($source == false || $target == false ) ? false : true;
    }

    /**
     * Translate a sentence in a source language to a target language.
     * A glossary can be used to ignore a word or translate by a defined word.
     * Examples:
     *      glossary: [['Hello' => 'Hello']] input: 'Hello Thomas' output: 'Hello Thomas'
     *      glossary: [['Hello' => 'Bye Bye']] input: 'Hello Thomas' output: 'Bye Bye Thomas'
     *
     * @param string $sentence
     * @param string $sourceLanguage
     * @param string $targetLanguage
     * @param array|null $glossary
     * @return string
     */
    public function translate(string $sentence, string $sourceLanguage, string $targetLanguage, array $glossary = null)
    {
        if(!$this->isSupported($sourceLanguage, $targetLanguage))
        throw new Exception('This language pair is not supported.');
    
        // Translation of sentence
        $result = $this->client->translate($sentence, [
        'target' => $targetLanguage,
        ]);

        // Translation with glossary
        if(!empty($glossary)){

            // glassory transaltion
            $glossary_new = $this->glossaryTranslation($glossary,$targetLanguage);

            // Replace the translate value source glossary with value target glossary in transalte sentence
            foreach ($glossary_new as $text_cible => $text_target){
                $result['text'] = preg_replace("/$text_cible/",$text_target,$result['text']);
            }  
        }

        return $result['text'];
    }

    /**
     * Translate sentences in a source language to a target language.
     * A glossary can be used to ignore a word or translate by a defined word.
     *
     * @param array $sentences
     * @param string $sourceLanguage
     * @param string $targetLanguage
     * @param array|null $glossary
     * @return array
     */
    public function multiTranslate(array $sentences, string $sourceLanguage, string $targetLanguage, array $glossary = null)
    {
        if(!$this->isSupported($sourceLanguage, $targetLanguage))
        throw new Exception('This language pair is not supported.');

        // Batch of sentences translation
        $results = $this->client->translateBatch($sentences, [
            'target' => $targetLanguage,
            ]);
        
        // Format array of results
        foreach ($results as $result) {
            $all_results[] = $result['text'];
        }
        
        if(!empty($glossary))
        {
            // glassory transaltion
            $glossary_new = $this->glossaryTranslation($glossary,$targetLanguage);

            // Replace the translate value source glossary with value target glossary in transalte sentence
            $i = 0;
            foreach ($glossary_new as $text_cible => $text_target){
                $all_results[$i] = preg_replace("/$text_cible/",$text_target,$all_results[$i]);
                $i++;
            }
        }
       return  $all_results;  
    }

    private function glossaryTranslation($glossary, $targetLanguage)
    {
        // For each glossary
        for ($i=0; $i <count($glossary);$i++){ 
            foreach ($glossary[$i] as $text_source => $text_target){  
                // Translation of source value to target language
                $translate_value = $this->client->translate($text_source, [
                'target' => $targetLanguage,
                ]);
                // Re buil new glossary
                $glossary_new[$translate_value['text']] = $text_target;
            }
        }
        return $glossary_new;
    }
}