<?php
namespace Translate;
use Google\Cloud\Translate\V2\TranslateClient;


/**
 * Class OffsetEncodingAlgorithm
 */
class Translate
{
    private $client;

    /**
     * Translate constructor.
     */
    public function __construct()
    {
        $this->client = new TranslateClient([
            'key' => 'AIzaSyDpjkvttfk-lZtZgoq_7KhrC6VIQAbiVdQ'
        ]);
    }

    /**
     * Return bool to know if language pair is supported.
     * @param string $sourceLanguage
     * @param string $targetLanguage
     * @return bool
     */
    public function isSupported(string $sourceLanguage, string $targetLanguage)
    {
        // TODO
        try {
            $languages = $this->client->localizedLanguages([
                "target" => $targetLanguage
             ]
            );

            foreach ($languages as $language){
                if ($language['code'] == $sourceLanguage)
                    return true;
            }
            throw new Exception("This language pair is not supported");
        }
        catch (Exception $e){
            print($e->getMessage());
            return false;
        }
    	
    }

    /**
     * Translate a sentence in a source language to a target language.
     * A glossary can be used to ignore a word or translate by a defined word.
     * Examples:
     *      glossary: [['Hello' => 'Hello']] input: 'Hello Thomas' output: 'Hello Thomas'
     *      glossary: [['Hello' => 'Bye Bye']] input: 'Hello Thomas' output: 'Bye Bye Thomas'
     *
     * @param string $sentence
     * @param string $sourceLanguage
     * @param string $targetLanguage
     * @param array|null $glossary
     * @return string
     */
    public function translate(string $sentence, string $sourceLanguage, string $targetLanguage, array $glossary = null)
    {

        try{
            $this->isSupported($sourceLanguage, $targetLanguage);
                
            $format = $this->isHTML($sentence);

            $translation = $this->client->translate($sentence, [
                'source' => $sourceLanguage,
                'target' => $targetLanguage,
                'format' => $format
            ]);

            return $translation['text'];
        }
        catch (Exception $e){
            print($e->getMessage());
        }
    }

    /**
     * Translate sentences in a source language to a target language.
     * A glossary can be used to ignore a word or translate by a defined word.
     *
     * @param array $sentences
     * @param string $sourceLanguage
     * @param string $targetLanguage
     * @param array|null $glossary
     * @return array
     */
    public function multiTranslate(array $sentences, string $sourceLanguage, string $targetLanguage, array $glossary = null)
    {
        try{
            $translatedSentences = array();

            $translations = $this->client->translateBatch($sentences, [
                'source' => $sourceLanguage,
                'target' => $targetLanguage,

            ]);

            foreach ($translations as $translation) {
                array_push($translatedSentences, $translation['text']);
            }

            return $translatedSentences;
        }
        catch(Exception $e)
        {
            print($e->getMessage());
        }
        
    }

    private function isHTML($sentence)
    {
       return $sentence != strip_tags($string) ? "html":"text";
    }

    
}
