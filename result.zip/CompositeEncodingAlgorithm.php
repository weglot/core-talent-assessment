<?php

/**
 *  Class CompositeEncodingAlgorithm
 */
class CompositeEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * @var EncodingAlgorithm[]
     */
    private $algorithms;

    /**
     *  CompositeEncodingAlgorithm constructor
     */
    public function __construct()
    {
        $this->algorithms = array();
    }

    /**
     * @param EncodingAlgorithm $algorithm
     */
    public function add(EncodingAlgorithm $algorithm)
    {
        $this->algorithms[] = $algorithm;
    }

    /**
     *  Encodes text using multiple Encoders stored in $this->algorithms (in orders encoders were added)
     *
     * @param string $text
     * @return string
     * http://www.writephponline.com/
     */
    public function encode($text)
    {
        if (isset($text) && is_string($text))
        {
            $ret = $text;
            foreach ($this->algorithms as $algo)
            {
                $ret = $algo->encode($ret);
            }

            return $ret;
        }
        return '';
    }
}
