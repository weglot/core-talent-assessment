<?php
include 'Node.php';

class CircularLinkedList{
	private $head;
	private $tail;
	private $data;

	public function __construct(string $data)
	{
		$this->head = null;
		$this->tail = null;
		$this->data = $data;
	}
	
	public function createList()
	{
		$dataArray = str_split($this->data);
	
		foreach ($dataArray as $char) {
			$node = new Node($char);
			$this->addNode($node);
		}
	}


	private function addNode($node)
	{
	   if ($this->head)
	   {
		$currentNode = $this->head;

		while ($currentNode->next != $this->head)
		{
			$currentNode = $currentNode->next;
		}
		$currentNode->next = $node;
		$this->tail = $node;
		$this->tail->next = $this->head;
	   }else{
		$this->head = $node;
		$this->tail = $node;
		$node->next = $this->head;
	   }
	}


	public function displayNode()
	{
		$currentNode = $this->head;
		print($currentNode->data);
		while ($currentNode->next != $this->head)
        {
		     $currentNode = $currentNode->next;
		     print($currentNode->data);
        }
	
	}


	public function getNode($letter)
	{
    	$currentNode = $this->head;
		if ($currentNode->data === $letter)
		{
			return $currentNode;
		}
		while ($currentNode->next != $this->head)
        {
			$currentNode = $currentNode->next;
			if ($currentNode->data === $letter){
				return $currentNode;
		   }
        }
	}


	public function getencodedLetter($node, $offset)
	{
  		$compteur = 0;
		$currentNode = $node;
  		while ($compteur < $offset)
  		{
        		$compteur++;
			$currentNode = $currentNode->next;
  		}
		return $currentNode->data;
	}

}
