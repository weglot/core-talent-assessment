<?php

/*
 * PHP LAB
 *
 * in CLI : php -S localhost:9000
 * then open your browser http://localhost:9000
 *
 * output
 * -------
 *
 * string(8) "bcd efg."
 * string(17) "upydm koslm epupy"
 * string(13) "bce dfa, hkj."
 *
 * */

require_once('EncodingAlgorithm.php');

require_once('OffsetEncodingAlgorithm.php');
require_once('SubstitutionEncodingAlgorithm.php');
require_once('CompositeEncodingAlgorithm.php');

$algorithmOffset = new OffsetEncodingAlgorithm(1);
$algorithmSubstitution = new SubstitutionEncodingAlgorithm(['ga', 'de', 'ry', 'po', 'lu', 'ki']);

$algorithmComposite = new CompositeEncodingAlgorithm();

$algorithmComposite->add($algorithmOffset);
$algorithmComposite->add($algorithmSubstitution);

$resultOffset = $algorithmOffset->encode('abc def.');
var_dump($resultOffset);

$resultSubstitution = $algorithmSubstitution->encode('lorem ipsum dolor');
var_dump($resultSubstitution);

$resultComposite = $algorithmComposite->encode('abc def, ghi.');
var_dump($resultComposite)

?>

