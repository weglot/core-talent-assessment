<?php

use Google\Cloud\Translate\V2\TranslateClient;

/**
 * Class OffsetEncodingAlgorithm
 */
class Translate
{
    private $client;

    /**
     * Translate constructor.
     */
    public function __construct()
    {
        $this->client = new TranslateClient([
            'key' => 'AIzaSyDpjkvttfk-lZtZgoq_7KhrC6VIQAbiVdQ'
        ]);
    }

    /**
     * Return bool to know if language pair is supported.
     * @param string $sourceLanguage
     * @param string $targetLanguage
     * @return bool
     */
    public function isSupported(string $sourceLanguage, string $targetLanguage)
    {
        // TODO
    }

    /**
     * Translate a sentence in a source language to a target language.
     * A glossary can be used to ignore a word or translate by a defined word.
     * Examples:
     *      glossary: [['Hello' => 'Hello']] input: 'Hello Thomas' output: 'Hello Thomas'
     *      glossary: [['Hello' => 'Bye Bye']] input: 'Hello Thomas' output: 'Bye Bye Thomas'
     *
     * @param string $sentence
     * @param string $sourceLanguage
     * @param string $targetLanguage
     * @param array|null $glossary
     * @return string
     */
    public function translate(string $sentence, string $sourceLanguage, string $targetLanguage, array $glossary = null)
    {
        // TODO
    }

    /**
     * Translate sentences in a source language to a target language.
     * A glossary can be used to ignore a word or translate by a defined word.
     *
     * @param array $sentences
     * @param string $sourceLanguage
     * @param string $targetLanguage
     * @param array|null $glossary
     * @return array
     */
    public function multiTranslate(array $sentences, string $sourceLanguage, string $targetLanguage, array $glossary = null)
    {
        // TODO
    }
}